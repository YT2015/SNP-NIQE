function feat = computefeature_fe(error)

 

feat          = [];



[alpha betal betar]      = estimateaggdparam(error(:));

feat                     = [feat;alpha;(betal+betar)/2];


