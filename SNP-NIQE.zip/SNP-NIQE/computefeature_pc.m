function feat = computefeature_pc(error)



feat          = [];
if (any(error(:)) == 0)
    error = error + 0.00001;
end

phat1 = wblfit(error(:));



feat                     = [feat;phat1'];