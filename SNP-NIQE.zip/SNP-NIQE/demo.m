 clear;
 clc;
 load modelparameters.mat
 
 blocksizerow    = 96;
 blocksizecol    = 96;
 blockrowoverlap = 0;
 blockcoloverlap = 0;
 
 I = imread('i12_08_5.bmp');
 I = rgb2gray(I);
 
 score = computequality(I,blocksizerow,blocksizecol,blockrowoverlap,blockcoloverlap,mu_prisparam,cov_prisparam)